import sys
import datetime
import time
import threading
import tkinter as tk
from tkinter import messagebox, ttk
from tkcalendar import Calendar, DateEntry
from PIL import ImageTk, Image, ImageSequence
from database import Database
from models import Paciente, Maqueiro, Tarefa, Incidente, SolicitacaoTransporte
from notificacoes import SistemaDeNotificacoes
from utils import input_senha
import random
import os
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

ADMIN_CREDENTIALS = {'login': 'admin', 'senha': 'admin123'}

def set_window_icon(window):
    """
    Define o ícone da janela.

    Args:
        window (tk.Tk or tk.Toplevel): A janela do Tkinter para definir o ícone.
    """
    icon_path = 'imagens/icon.ico'
    if os.path.exists(icon_path):
        window.iconbitmap(icon_path)

def exibir_menu_admin(sistema_notificacoes, db):
    """
    Exibe o menu do administrador.

    Args:
        sistema_notificacoes (SistemaDeNotificacoes): O sistema de notificações.
        db (Database): A instância do banco de dados.
    """
    def voltar():
        """
        Volta para a tela de login.
        """
        admin_menu_window.destroy()
        root.deiconify()  

    def validar_entrada(entrada, tipo):
        """
        Valida se uma entrada foi fornecida.

        Args:
            entrada (str): O valor da entrada.
            tipo (str): O tipo de entrada.

        Returns:
            bool: True se a entrada for válida, False caso contrário.
        """
        if not entrada:
            messagebox.showerror("Erro", f"O campo {tipo} é obrigatório.")
            return False
        return True

    def validar_cpf(cpf):
        """
        Valida o CPF fornecido.

        Args:
            cpf (str): O CPF a ser validado.

        Returns:
            bool: True se o CPF for válido, False caso contrário.
        """
        if not cpf.isdigit() or len(cpf) != 11:
            messagebox.showerror("Erro", "O CPF deve conter 11 dígitos numéricos.")
            return False
        if db.buscar_maqueiro_por_cpf(cpf):
            messagebox.showerror("Erro", "Já existe um maqueiro cadastrado com este CPF.")
            return False
        return True

    def validar_senha(senha):
        """
        Valida a senha fornecida.

        Args:
            senha (str): A senha a ser validada.

        Returns:
            bool: True se a senha for válida, False caso contrário.
        """
        if len(senha) < 8:
            messagebox.showerror("Erro", "A senha deve conter no mínimo 8 caracteres.")
            return False
        return True

    def validar_data_nascimento(data_nascimento):
        """
        Valida a data de nascimento fornecida.

        Args:
            data_nascimento (str): A data de nascimento a ser validada.

        Returns:
            bool: True se a data de nascimento for válida, False caso contrário.
        """
        nascimento = datetime.datetime.strptime(data_nascimento, "%d-%m-%Y")
        idade = (datetime.datetime.now() - nascimento).days // 365
        if idade < 20:
            messagebox.showerror("Erro", "O maqueiro deve ter no mínimo 20 anos.")
            return False
        return True

    def cadastrar_maqueiro():
        """
        Abre a janela para cadastrar um novo maqueiro.
        """
        def salvar_maqueiro():
            """
            Salva o novo maqueiro no banco de dados.
            """
            nome = entry_nome.get()
            cpf = entry_cpf.get()
            data_nascimento = entry_data_nascimento.get()
            sexo = entry_sexo.get()
            senha = entry_senha.get()

            if not (validar_entrada(nome, "Nome") and validar_entrada(cpf, "CPF") and validar_cpf(cpf) and
                    validar_entrada(data_nascimento, "Data de Nascimento") and validar_data_nascimento(data_nascimento) and
                    validar_entrada(sexo, "Sexo") and validar_entrada(senha, "Senha") and validar_senha(senha)):
                return

            maqueiro = Maqueiro(None, nome, cpf, data_nascimento, sexo)
            maqueiro.login = cpf
            maqueiro.senha = senha
            db.insert_maqueiro(maqueiro)
            messagebox.showinfo("Sucesso", f"Maqueiro {nome} cadastrado com sucesso.")
            maqueiro_window.destroy()

        maqueiro_window = tk.Toplevel(admin_menu_window)
        maqueiro_window.title("Cadastrar Maqueiro")
        maqueiro_window.geometry("1366x768")
        set_window_icon(maqueiro_window)

        tk.Label(maqueiro_window, text="Nome:", bg="lightgrey").pack()
        entry_nome = tk.Entry(maqueiro_window)
        entry_nome.pack()

        tk.Label(maqueiro_window, text="CPF:", bg="lightgrey").pack()
        entry_cpf = tk.Entry(maqueiro_window)
        entry_cpf.pack()

        tk.Label(maqueiro_window, text="Data de Nascimento (dd-MM-yyyy):", bg="lightgrey").pack()
        entry_data_nascimento = DateEntry(maqueiro_window, date_pattern='dd-MM-yyyy')
        entry_data_nascimento.pack()

        tk.Label(maqueiro_window, text="Sexo (M/F):", bg="lightgrey").pack()
        entry_sexo = tk.Entry(maqueiro_window)
        entry_sexo.pack()

        tk.Label(maqueiro_window, text="Senha:", bg="lightgrey").pack()
        entry_senha = tk.Entry(maqueiro_window, show="*")
        entry_senha.pack()

        tk.Button(maqueiro_window, text="Salvar", command=salvar_maqueiro).pack()
        tk.Button(maqueiro_window, text="Voltar", command=maqueiro_window.destroy).pack()

    admin_menu_window = tk.Toplevel(root)
    admin_menu_window.title("Menu do Administrador")
    admin_menu_window.geometry("1366x768")
    set_window_icon(admin_menu_window)

    tk.Button(admin_menu_window, text="Cadastrar Maqueiro", command=cadastrar_maqueiro, width=30).pack(pady=5)
    tk.Button(admin_menu_window, text="Voltar", command=voltar, width=30).pack(pady=5)

    admin_menu_window.protocol("WM_DELETE_WINDOW", voltar)

def exibir_menu(sistema_notificacoes, maqueiro_logado, pacientes, maqueiros, tarefas, db):
    """
    Exibe o menu principal para os maqueiros logados.

    Args:
        sistema_notificacoes (SistemaDeNotificacoes): O sistema de notificações.
        maqueiro_logado (Maqueiro): O maqueiro atualmente logado.
        pacientes (list): A lista de pacientes.
        maqueiros (list): A lista de maqueiros.
        tarefas (list): A lista de tarefas.
        db (Database): A instância do banco de dados.
    """
    solicitacoes_transporte = db.listar_solicitacoes_pendentes()

    def sair():
        """
        Fecha a conexão com o banco de dados e volta para a tela de login.
        """

        db.close_connection()
        menu_window.destroy()
        root.deiconify()  

    menu_window = tk.Toplevel(root)
    menu_window.title("Menu")
    menu_window.geometry("1366x768")
    set_window_icon(menu_window)

    # Carregar a imagem de fundo
    bg_image = Image.open("imagens/hospital_system.png")
    bg_image = bg_image.resize((1366, 768), Image.LANCZOS)
    bg_photo = ImageTk.PhotoImage(bg_image)
    bg_label = tk.Label(menu_window, image=bg_photo)
    bg_label.image = bg_photo  
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)

    # Frame para centralizar os botões do menu
    menu_frame = tk.Frame(menu_window, bg="white")
    menu_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

    # Frames para agrupar os botões
    frame_pacientes = tk.Frame(menu_frame, bg="lightgrey", bd=2, relief=tk.SUNKEN, padx=10, pady=10)
    frame_transporte = tk.Frame(menu_frame, bg="lightgrey", bd=2, relief=tk.SUNKEN, padx=10, pady=10)
    frame_tarefas_incidentes = tk.Frame(menu_frame, bg="lightgrey", bd=2, relief=tk.SUNKEN, padx=10, pady=10)
    frame_geral = tk.Frame(menu_frame, bg="lightgrey", bd=2, relief=tk.SUNKEN, padx=10, pady=10)

    frame_pacientes.grid(row=0, column=0, padx=20, pady=20, sticky="n")
    frame_transporte.grid(row=0, column=1, padx=20, pady=20, sticky="n")
    frame_tarefas_incidentes.grid(row=1, column=0, padx=20, pady=20, sticky="n")
    frame_geral.grid(row=1, column=1, padx=20, pady=20, sticky="n")

    def validar_entrada(entrada, tipo):
        """
        Valida se uma entrada foi fornecida.

        Args:
            entrada (str): O valor da entrada.
            tipo (str): O tipo de entrada.

        Returns:
            bool: True se a entrada for válida, False caso contrário.
        """
        if not entrada:
            messagebox.showerror("Erro", f"O campo {tipo} é obrigatório.")
            return False
        return True

    def validar_cpf(cpf):
        """
        Valida o CPF fornecido.

        Args:
            cpf (str): O CPF a ser validado.

        Returns:
            bool: True se o CPF for válido, False caso contrário.
        """
        if not cpf.isdigit() or len(cpf) != 11:
            messagebox.showerror("Erro", "O CPF deve conter 11 dígitos numéricos.")
            return False
        return True

    def validar_data_hora(data, hora):
        """
        Valida a data e hora fornecidas.

        Args:
            data (str): A data a ser validada.
            hora (str): A hora a ser validada.

        Returns:
            bool: True se a data e hora forem válidas, False caso contrário.
        """
        try:
            datetime.datetime.strptime(f"{data} {hora}", "%d-%m-%Y %H:%M:%S")
            return True
        except ValueError:
            messagebox.showerror("Erro", "A data e hora devem estar no formato dd-MM-yyyy e HH:MM:SS.")
            return False

    def cadastrar_paciente():
        """
        Abre a janela para cadastrar um novo paciente.
        """
        def salvar_paciente():
            """
            Salva o novo paciente no banco de dados.
            """
            nome = entry_nome.get()
            cpf = entry_cpf.get()
            localizacao = entry_localizacao.get()
            condicao = text_condicao.get("1.0", "end-1c")
            urgencia = combobox_urgencia.get()
            transporte = 'Aguardando transporte'
            if not (validar_entrada(nome, "Nome") and validar_entrada(cpf, "CPF") and validar_cpf(cpf) and
                    validar_entrada(localizacao, "Localização") and validar_entrada(condicao, "Condição") and 
                    validar_entrada(urgencia, "Urgência")):
                return
            if db.buscar_paciente_por_cpf(cpf):
                messagebox.showerror("Erro", "CPF já cadastrado para outro paciente.")
                return
            paciente = Paciente(nome, cpf, localizacao, condicao, transporte, urgencia)
            paciente_id = db.insert_paciente(paciente)
            paciente.id = paciente_id
            pacientes.append(paciente)
            messagebox.showinfo("Sucesso", f"Paciente {nome} cadastrado com sucesso.")
            paciente_window.destroy()

        paciente_window = tk.Toplevel(menu_window)
        paciente_window.title("Cadastrar Paciente")
        paciente_window.geometry("1366x768")
        set_window_icon(paciente_window)

        tk.Label(paciente_window, text="Nome:", bg="lightgrey").pack()
        entry_nome = tk.Entry(paciente_window)
        entry_nome.pack()

        tk.Label(paciente_window, text="CPF:", bg="lightgrey").pack()
        entry_cpf = tk.Entry(paciente_window)
        entry_cpf.pack()

        tk.Label(paciente_window, text="Localização:", bg="lightgrey").pack()
        entry_localizacao = tk.Entry(paciente_window)
        entry_localizacao.pack()

        tk.Label(paciente_window, text="Condição:", bg="lightgrey").pack()
        text_condicao = tk.Text(paciente_window, height=5, width=40)
        text_condicao.pack()

        tk.Label(paciente_window, text="Urgência:", bg="lightgrey").pack()
        urgencias = ['Emergencia', 'Urgência', 'Pouco Urgente', 'Não urgente']
        combobox_urgencia = ttk.Combobox(paciente_window, values=urgencias)
        combobox_urgencia.pack()

        tk.Button(paciente_window, text="Salvar", command=salvar_paciente).pack()

    def ver_status_pacientes():
        """
        Exibe a janela com o status dos pacientes cadastrados.
        """
        pacientes = db.listar_pacientes_por_urgencia()
        status_window = tk.Toplevel(menu_window)
        status_window.title("Status dos Pacientes")
        status_window.geometry("1366x768")
        set_window_icon(status_window)

        columns = ("ID", "Nome", "CPF", "Localização", "Condição", "Urgência", "Status Transporte")
        tree = ttk.Treeview(status_window, columns=columns, show="headings")
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=150)
        
        for paciente in pacientes:
            tree.insert("", "end", values=(paciente.id, paciente.nome, paciente.cpf, paciente.localizacao, paciente.condicao, paciente.urgencia, paciente.transporte))
        
        def on_double_click(event):
            """
            Exibe os detalhes do paciente ao clicar duas vezes em um item da lista.

            Args:
                event (tk.Event): O evento de clique duplo.
            """
            item = tree.selection()[0]
            paciente_id = tree.item(item, "values")[0]
            exibir_detalhes_paciente(paciente_id)

        tree.bind("<Double-1>", on_double_click)
        
        tree.pack(expand=True, fill="both")
        scrollbar = ttk.Scrollbar(status_window, orient="vertical", command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side="right", fill="y")

    def exibir_detalhes_paciente(paciente_id):
        """
        Exibe os detalhes de um paciente específico.

        Args:
            paciente_id (int): O ID do paciente.
        """
        paciente = db.buscar_paciente_por_id(paciente_id)
        if not paciente:
            messagebox.showerror("Erro", "Paciente não encontrado.")
            return

        detalhes_window = tk.Toplevel(menu_window)
        detalhes_window.title(f"Detalhes do Paciente {paciente.nome}")
        detalhes_window.geometry("600x400")
        set_window_icon(detalhes_window)

        detalhes_frame = tk.Frame(detalhes_window, padx=10, pady=10, bg="lightgrey")
        detalhes_frame.pack(expand=True, fill=tk.BOTH)

        tk.Label(detalhes_frame, text=f"ID: {paciente.id}", font=("Helvetica", 12), bg="lightgrey").grid(row=0, column=0, sticky=tk.W, pady=5)
        tk.Label(detalhes_frame, text=f"Nome: {paciente.nome}", font=("Helvetica", 12), bg="lightgrey").grid(row=1, column=0, sticky=tk.W, pady=5)
        tk.Label(detalhes_frame, text=f"CPF: {paciente.cpf}", font=("Helvetica", 12), bg="lightgrey").grid(row=2, column=0, sticky=tk.W, pady=5)
        tk.Label(detalhes_frame, text=f"Localização: {paciente.localizacao}", font=("Helvetica", 12), bg="lightgrey").grid(row=3, column=0, sticky=tk.W, pady=5)
        tk.Label(detalhes_frame, text=f"Condição: {paciente.condicao}", font=("Helvetica", 12), bg="lightgrey").grid(row=4, column=0, sticky=tk.W, pady=5)
        tk.Label(detalhes_frame, text=f"Urgência: {paciente.urgencia}", font=("Helvetica", 12), bg="lightgrey").grid(row=5, column=0, sticky=tk.W, pady=5)
        tk.Label(detalhes_frame, text=f"Status Transporte: {paciente.transporte}", font=("Helvetica", 12), bg="lightgrey").grid(row=6, column=0, sticky=tk.W, pady=5)

    def listar_tarefas_pendentes():
        """
        Exibe a janela com a lista de tarefas pendentes.
        """
        tarefas_pendentes = db.listar_tarefas_pendentes()
        tarefas_window = tk.Toplevel(menu_window)
        tarefas_window.title("Tarefas Pendentes")
        tarefas_window.geometry("1366x768")
        set_window_icon(tarefas_window)

        columns = ("ID", "Descrição", "Prioridade", "Paciente", "Localização")
        tree = ttk.Treeview(tarefas_window, columns=columns, show="headings")
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=150)
        
        for tarefa in tarefas_pendentes:
            tree.insert("", "end", values=(tarefa.id, tarefa.descricao, tarefa.prioridade, tarefa.paciente.nome, tarefa.localizacao))
        
        tree.pack(expand=True, fill="both")
        scrollbar = ttk.Scrollbar(tarefas_window, orient="vertical", command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side="right", fill="y")

    def ver_solicitacoes():
        """
        Exibe a janela com as solicitações de transporte pendentes.
        """
        solicitacoes = db.listar_solicitacoes_pendentes()
        solicitacoes_window = tk.Toplevel(menu_window)
        solicitacoes_window.title("Solicitações de Transporte")
        solicitacoes_window.geometry("1366x768")
        set_window_icon(solicitacoes_window)

        columns = ("ID", "Descrição", "Paciente", "Urgência", "Status")
        tree = ttk.Treeview(solicitacoes_window, columns=columns, show="headings")
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=150)
        
        for solicitacao in solicitacoes:
            tree.insert("", "end", values=(solicitacao.id, solicitacao.descricao, solicitacao.paciente.nome, solicitacao.paciente.urgencia, solicitacao.status))
        
        tree.pack(expand=True, fill="both")
        scrollbar = ttk.Scrollbar(solicitacoes_window, orient="vertical", command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side="right", fill="y")

    def adicionar_tarefa():
        """
        Abre a janela para adicionar uma nova tarefa.
        """
        def salvar_tarefa():
            """
            Salva a nova tarefa no banco de dados.
            """
            descricao = entry_descricao.get()
            prioridade = entry_prioridade.get()
            cpf_paciente = entry_cpf_paciente.get()
            localizacao = entry_localizacao.get()
            if not (validar_entrada(descricao, "Descrição") and validar_entrada(prioridade, "Prioridade") and
                    validar_entrada(cpf_paciente, "CPF do Paciente") and validar_cpf(cpf_paciente) and 
                    validar_entrada(localizacao, "Localização")):
                return
            paciente = db.buscar_paciente_por_cpf(cpf_paciente)
            if not paciente:
                messagebox.showerror("Erro", "Paciente não encontrado.")
                return
            tarefa = Tarefa(None, descricao, prioridade, paciente, localizacao, maqueiro_logado)
            tarefa_id = db.insert_tarefa(tarefa)
            tarefa.id = tarefa_id
            tarefas.append(tarefa)
            messagebox.showinfo("Sucesso", f"Tarefa '{descricao}' adicionada com sucesso.")
            tarefa_window.destroy()

        tarefa_window = tk.Toplevel(menu_window)
        tarefa_window.title("Adicionar Tarefa")
        tarefa_window.geometry("1366x768")
        set_window_icon(tarefa_window)

        tk.Label(tarefa_window, text="Descrição:", bg="lightgrey").pack()
        entry_descricao = tk.Entry(tarefa_window)
        entry_descricao.pack()

        tk.Label(tarefa_window, text="Prioridade:", bg="lightgrey").pack()
        entry_prioridade = tk.Entry(tarefa_window)
        entry_prioridade.pack()

        tk.Label(tarefa_window, text="CPF do Paciente:", bg="lightgrey").pack()
        entry_cpf_paciente = tk.Entry(tarefa_window)
        entry_cpf_paciente.pack()

        tk.Label(tarefa_window, text="Localização:", bg="lightgrey").pack()
        entry_localizacao = tk.Entry(tarefa_window)
        entry_localizacao.pack()

        tk.Button(tarefa_window, text="Salvar", command=salvar_tarefa).pack()

    def concluir_tarefa():
        """
        Abre a janela para concluir uma tarefa.
        """
        def salvar_conclusao():
            """
            Salva a conclusão da tarefa no banco de dados.
            """
            id_tarefa = entry_id_tarefa.get()
            if not validar_entrada(id_tarefa, "ID da Tarefa"):
                return
            tarefa = next((t for t in tarefas if t.id == int(id_tarefa)), None)
            if not tarefa:
                messagebox.showerror("Erro", "Tarefa não encontrada.")
                return
            tarefa.status = 'concluída'
            db.update_tarefa_status(tarefa.id, tarefa.status)
            messagebox.showinfo("Sucesso", f"Tarefa {id_tarefa} concluída com sucesso.")
            conclusao_window.destroy()

        conclusao_window = tk.Toplevel(menu_window)
        conclusao_window.title("Concluir Tarefa")
        conclusao_window.geometry("1366x768")
        set_window_icon(conclusao_window)

        tk.Label(conclusao_window, text="ID da Tarefa:", bg="lightgrey").pack()
        entry_id_tarefa = tk.Entry(conclusao_window)
        entry_id_tarefa.pack()

        tk.Button(conclusao_window, text="Salvar", command=salvar_conclusao).pack()

    def relatar_incidente():
        """
        Abre a janela para relatar um incidente.
        """
        def salvar_incidente():
            """
            Salva o incidente relatado no banco de dados.
            """
            descricao = entry_descricao.get()
            cpf_paciente = entry_cpf_paciente.get()
            data = entry_data.get()
            hora = entry_hora.get()
            gravidade = combobox_gravidade.get()
            localizacao = entry_localizacao.get()
            acoes_tomadas = text_acoes_tomadas.get("1.0", "end-1c")
            testemunhas = entry_testemunhas.get()

            if not (validar_entrada(descricao, "Descrição") and validar_entrada(cpf_paciente, "CPF do Paciente") and 
                    validar_cpf(cpf_paciente) and validar_entrada(data, "Data") and 
                    validar_entrada(hora, "Hora") and validar_data_hora(data, hora) and
                    validar_entrada(gravidade, "Gravidade") and validar_entrada(localizacao, "Localização") and
                    validar_entrada(acoes_tomadas, "Ações Tomadas") and validar_entrada(testemunhas, "Testemunhas")):
                return

            paciente = db.buscar_paciente_por_cpf(cpf_paciente)
            if not paciente:
                messagebox.showerror("Erro", "Paciente não encontrado.")
                return
            
            incidente = Incidente(None, descricao, maqueiro_logado, paciente, f"{data} {hora}", gravidade, localizacao, acoes_tomadas, testemunhas)
            db.insert_incidente(incidente)
            messagebox.showinfo("Sucesso", "Incidente registrado com sucesso.")
            incidente_window.destroy()

        incidente_window = tk.Toplevel(menu_window)
        incidente_window.title("Relatar Incidente")
        incidente_window.geometry("1366x768")
        set_window_icon(incidente_window)

        tk.Label(incidente_window, text="Descrição:", bg="lightgrey").pack()
        entry_descricao = tk.Entry(incidente_window)
        entry_descricao.pack()

        tk.Label(incidente_window, text="CPF do Paciente:", bg="lightgrey").pack()
        entry_cpf_paciente = tk.Entry(incidente_window)
        entry_cpf_paciente.pack()

        tk.Label(incidente_window, text="Data (dd-MM-yyyy):", bg="lightgrey").pack()
        entry_data = DateEntry(incidente_window, date_pattern='dd-MM-yyyy')
        entry_data.pack()

        tk.Label(incidente_window, text="Hora (HH:MM:SS):", bg="lightgrey").pack()
        entry_hora = tk.Entry(incidente_window)
        entry_hora.pack()

        tk.Label(incidente_window, text="Gravidade:", bg="lightgrey").pack()
        gravidades = ['Leve', 'Moderada', 'Grave', 'Crítica']
        combobox_gravidade = ttk.Combobox(incidente_window, values=gravidades)
        combobox_gravidade.pack()

        tk.Label(incidente_window, text="Localização:", bg="lightgrey").pack()
        entry_localizacao = tk.Entry(incidente_window)
        entry_localizacao.pack()

        tk.Label(incidente_window, text="Ações Tomadas:", bg="lightgrey").pack()
        text_acoes_tomadas = tk.Text(incidente_window, height=5, width=40)
        text_acoes_tomadas.pack()

        tk.Label(incidente_window, text="Testemunhas:", bg="lightgrey").pack()
        entry_testemunhas = tk.Entry(incidente_window)
        entry_testemunhas.pack()

        tk.Button(incidente_window, text="Salvar", command=salvar_incidente).pack()

    def solicitar_transporte():
        """
        Abre a janela para solicitar o transporte de um paciente.
        """
        def salvar_solicitacao():
            """
            Salva a nova solicitação de transporte no banco de dados.
            """
            descricao = entry_descricao.get()
            cpf_paciente = entry_cpf_paciente.get()
            data = entry_data.get()
            hora = entry_hora.get()
            if not (validar_entrada(descricao, "Descrição") and validar_entrada(cpf_paciente, "CPF do Paciente") and 
                    validar_cpf(cpf_paciente) and validar_entrada(data, "Data") and 
                    validar_entrada(hora, "Hora") and validar_data_hora(data, hora)):
                return
            paciente = db.buscar_paciente_por_cpf(cpf_paciente)
            if not paciente:
                messagebox.showerror("Erro", "Paciente não encontrado.")
                return
            solicitacao = SolicitacaoTransporte(None, descricao, paciente, f"{data} {hora}", maqueiro_logado, "pendente")
            solicitacao_id = db.insert_solicitacao_transporte(solicitacao)
            solicitacao.id = solicitacao_id
            solicitacoes_transporte.append(solicitacao)
            messagebox.showinfo("Sucesso", "Solicitação de transporte registrada com sucesso.")
            solicitacao_window.destroy()

        solicitacao_window = tk.Toplevel(menu_window)
        solicitacao_window.title("Solicitar Transporte de Paciente")
        solicitacao_window.geometry("1366x768")
        set_window_icon(solicitacao_window)

        tk.Label(solicitacao_window, text="Descrição:", bg="lightgrey").pack()
        entry_descricao = tk.Entry(solicitacao_window)
        entry_descricao.pack()

        tk.Label(solicitacao_window, text="CPF do Paciente:", bg="lightgrey").pack()
        entry_cpf_paciente = tk.Entry(solicitacao_window)
        entry_cpf_paciente.pack()

        tk.Label(solicitacao_window, text="Data (dd-MM-yyyy):", bg="lightgrey").pack()
        entry_data = DateEntry(solicitacao_window, date_pattern='dd-MM-yyyy')
        entry_data.pack()

        tk.Label(solicitacao_window, text="Hora (HH:MM:SS):", bg="lightgrey").pack()
        entry_hora = tk.Entry(solicitacao_window)
        entry_hora.pack()

        tk.Button(solicitacao_window, text="Salvar", command=salvar_solicitacao).pack()

    def aceitar_ou_recusar_solicitacao():
        """
        Abre a janela para aceitar ou recusar uma solicitação de transporte.
        """
        def salvar_decisao():
            """
            Salva a decisão de aceitar ou recusar a solicitação de transporte.
            """
            id_solicitacao = entry_id_solicitacao.get()
            acao = entry_acao.get().upper()
            if not (validar_entrada(id_solicitacao, "ID da Solicitação") and validar_entrada(acao, "Ação")):
                return
            solicitacao = next((s for s in solicitacoes_transporte if s.id == int(id_solicitacao)), None)
            if not solicitacao:
                messagebox.showerror("Erro", "Solicitação não encontrada.")
                return
            if acao == 'A':
                solicitacao.status = 'aceita'
                db.update_solicitacao_status(solicitacao.id, solicitacao.status, maqueiro_logado.id)
                db.iniciar_transporte_paciente(solicitacao.paciente.id)
                messagebox.showinfo("Sucesso", f"Solicitação {id_solicitacao} aceita com sucesso.")
                criar_barra_progresso(solicitacao)
            elif acao == 'R':
                solicitacao.status = 'recusada'
                db.update_solicitacao_status(solicitacao.id, solicitacao.status, maqueiro_logado.id)
                messagebox.showinfo("Sucesso", f"Solicitação {id_solicitacao} recusada com sucesso.")
            else:
                messagebox.showerror("Erro", "Ação inválida.")
            decisao_window.destroy()

        decisao_window = tk.Toplevel(menu_window)
        decisao_window.title("Aceitar ou Recusar Solicitação")
        decisao_window.geometry("1366x768")
        set_window_icon(decisao_window)

        tk.Label(decisao_window, text="ID da Solicitação:", bg="lightgrey").pack()
        entry_id_solicitacao = tk.Entry(decisao_window)
        entry_id_solicitacao.pack()

        tk.Label(decisao_window, text="Deseja aceitar (A) ou recusar (R) a solicitação?", bg="lightgrey").pack()
        entry_acao = tk.Entry(decisao_window)
        entry_acao.pack()

        tk.Button(decisao_window, text="Salvar", command=salvar_decisao).pack()

    def criar_barra_progresso(solicitacao):
        """
        Cria uma barra de progresso para o transporte de um paciente.

        Args:
            solicitacao (SolicitacaoTransporte): A solicitação de transporte do paciente.
        """
        gif = Image.open('imagens/mudanca.gif')
        frames = [ImageTk.PhotoImage(frame) for frame in ImageSequence.Iterator(gif)]

        width, height = gif.size
        progresso_window = tk.Toplevel(menu_window)
        progresso_window.title(f"Transporte de {solicitacao.paciente.nome}")
        progresso_window.geometry(f"{width}x{height+100}")
        set_window_icon(progresso_window)

        tk.Label(progresso_window, text=f"Transporte de {solicitacao.paciente.nome}", bg="lightgrey").pack()

        canvas = tk.Canvas(progresso_window, width=width, height=height, bg="lightgrey")
        canvas.pack()

        progress = tk.DoubleVar()
        progress_bar = ttk.Progressbar(progresso_window, orient='horizontal', length=width, mode='determinate', variable=progress)
        progress_bar.pack()

        def update_frame(frame_index):
            """
            Atualiza o frame do GIF.

            Args:
                frame_index (int): O índice do frame a ser atualizado.
            """
            frame = frames[frame_index]
            canvas.create_image(0, 0, anchor=tk.NW, image=frame)
            progresso_window.after(100, update_frame, (frame_index + 1) % len(frames))

        def update_progress():
            """
            Atualiza a barra de progresso e o status do transporte do paciente.
            """
            increment = random.uniform(5, 10)  
            new_value = progress.get() + increment
            if new_value < 100:
                progress.set(new_value)
                progresso_window.after(500, update_progress)
                db.atualizar_transporte_paciente(solicitacao.paciente.id, "Em transporte")
            else:
                progress.set(100)
                db.concluir_transporte_paciente(solicitacao.paciente.id)
                db.mover_solicitacao_para_historico(solicitacao.id)  
                messagebox.showinfo("Sucesso", "Transporte concluído!")
                progresso_window.destroy()
                solicitacoes_transporte.remove(solicitacao)

        update_frame(0)
        update_progress()

    def gerar_relatorio():
        """
        Gera um relatório com a distribuição de urgências e status de transporte dos pacientes.
        """
        pacientes = db.listar_pacientes()
        transportes = [paciente.transporte for paciente in pacientes]
        urgencias = [paciente.urgencia for paciente in pacientes]

        # Mapeamento de cores para cada nível de urgência
        cores_urgencia = {
            'Emergencia': 'red',
            'Urgência': 'yellow',
            'Pouco Urgente': 'green',
            'Não urgente': 'blue'
        }

        # Mapeamento de cores para cada status de transporte
        cores_transporte = {
            'Aguardando transporte': 'orange',
            'Em transporte': 'blue',
            'Chegou ao destino': 'green'
        }

        # Contar a quantidade de cada urgência
        urgencia_labels = ['Emergencia', 'Urgência', 'Pouco Urgente', 'Não urgente']
        urgencia_counts = [urgencias.count(label) for label in urgencia_labels]

        # Contar a quantidade de cada status de transporte
        transporte_labels = ['Aguardando transporte', 'Em transporte', 'Chegou ao destino']
        transporte_counts = [transportes.count(label) for label in transporte_labels]

        fig, ax = plt.subplots(1, 2, figsize=(14, 7))

        # Gráfico de distribuição de urgências com cores personalizadas
        bars_urgencia = ax[0].bar(urgencia_labels, urgencia_counts, color=[cores_urgencia[label] for label in urgencia_labels])
        ax[0].set_title('Distribuição de Urgências dos Pacientes')
        ax[0].set_xlabel('Urgência')
        ax[0].set_ylabel('Número de Pacientes')

        # Adicionar rótulos de contagem acima das barras
        for bar in bars_urgencia:
            height = bar.get_height()
            ax[0].annotate('{}'.format(height),
                           xy=(bar.get_x() + bar.get_width() / 2, height),
                           xytext=(0, 3),  # 3 points vertical offset
                           textcoords="offset points",
                           ha='center', va='bottom')

        # Gráfico de distribuição de transportes com cores personalizadas
        bars_transporte = ax[1].bar(transporte_labels, transporte_counts, color=[cores_transporte[label] for label in transporte_labels])
        ax[1].set_title('Distribuição de Status de Transporte dos Pacientes')
        ax[1].set_xlabel('Status de Transporte')
        ax[1].set_ylabel('Número de Pacientes')

        # Adicionar rótulos de contagem acima das barras
        for bar in bars_transporte:
            height = bar.get_height()
            ax[1].annotate('{}'.format(height),
                           xy=(bar.get_x() + bar.get_width() / 2, height),
                           xytext=(0, 3),  # 3 points vertical offset
                           textcoords="offset points",
                           ha='center', va='bottom')

        plt.tight_layout()

        relatorio_window = tk.Toplevel(menu_window)
        relatorio_window.title("Relatório")
        relatorio_window.geometry("1366x768")
        set_window_icon(relatorio_window)

        canvas = FigureCanvasTkAgg(fig, master=relatorio_window)
        canvas.draw()
        canvas.get_tk_widget().pack(expand=True, fill=tk.BOTH)

    def atualizar_status_paciente():
        """
        Abre a janela para atualizar o status de um paciente.
        """
        def salvar_atualizacao():
            """
            Salva a atualização do status do paciente no banco de dados.
            """
            cpf = entry_cpf.get()
            nova_urgencia = combobox_nova_urgencia.get()
            nova_localizacao = entry_nova_localizacao.get()
            nova_condicao = text_nova_condicao.get("1.0", "end-1c")

            paciente = db.buscar_paciente_por_cpf(cpf)
            if not paciente:
                messagebox.showerror("Erro", "Paciente não encontrado.")
                return

            if nova_urgencia:
                paciente.urgencia = nova_urgencia
            if nova_localizacao:
                paciente.localizacao = nova_localizacao
            if nova_condicao:
                paciente.condicao = nova_condicao

            db.atualizar_paciente(paciente)
            messagebox.showinfo("Sucesso", "Status do paciente atualizado com sucesso.")
            atualizar_window.destroy()

        atualizar_window = tk.Toplevel(menu_window)
        atualizar_window.title("Atualizar Status do Paciente")
        atualizar_window.geometry("1366x768")
        set_window_icon(atualizar_window)

        tk.Label(atualizar_window, text="CPF do Paciente:", bg="lightgrey").pack()
        entry_cpf = tk.Entry(atualizar_window)
        entry_cpf.pack()

        tk.Label(atualizar_window, text="Nova Urgência:", bg="lightgrey").pack()
        urgencias = ['Emergencia', 'Urgência', 'Pouco Urgente', 'Não urgente']
        combobox_nova_urgencia = ttk.Combobox(atualizar_window, values=urgencias)
        combobox_nova_urgencia.pack()

        tk.Label(atualizar_window, text="Nova Localização:", bg="lightgrey").pack()
        entry_nova_localizacao = tk.Entry(atualizar_window)
        entry_nova_localizacao.pack()

        tk.Label(atualizar_window, text="Nova Condição:", bg="lightgrey").pack()
        text_nova_condicao = tk.Text(atualizar_window, height=5, width=40)
        text_nova_condicao.pack()

        tk.Button(atualizar_window, text="Salvar", command=salvar_atualizacao).pack()

    def liberar_paciente():
        """
        Abre a janela para liberar um paciente.
        """
        def salvar_liberacao():
            """
            Salva a liberação do paciente no banco de dados.
            """
            cpf = entry_cpf.get()

            paciente = db.buscar_paciente_por_cpf(cpf)
            if not paciente:
                messagebox.showerror("Erro", "Paciente não encontrado.")
                return

            db.liberar_paciente(paciente.id)
            messagebox.showinfo("Sucesso", "Paciente liberado com sucesso.")
            liberar_window.destroy()

        liberar_window = tk.Toplevel(menu_window)
        liberar_window.title("Liberar Paciente")
        liberar_window.geometry("1366x768")
        set_window_icon(liberar_window)

        tk.Label(liberar_window, text="CPF do Paciente:", bg="lightgrey").pack()
        entry_cpf = tk.Entry(liberar_window)
        entry_cpf.pack()

        tk.Button(liberar_window, text="Salvar", command=salvar_liberacao).pack()

    def reativar_paciente():
        """
        Abre a janela para reativar um paciente.
        """
        def salvar_reativacao():
            """
            Salva a reativação do paciente no banco de dados.
            """
            cpf = entry_cpf.get()

            paciente = db.buscar_paciente_por_cpf(cpf)
            if not paciente:
                messagebox.showerror("Erro", "Paciente não encontrado.")
                return

            db.reativar_paciente(cpf)
            messagebox.showinfo("Sucesso", "Paciente reativado com sucesso.")
            reativar_window.destroy()

        reativar_window = tk.Toplevel(menu_window)
        reativar_window.title("Reativar Paciente")
        reativar_window.geometry("1366x768")
        set_window_icon(reativar_window)

        tk.Label(reativar_window, text="CPF do Paciente:", bg="lightgrey").pack()
        entry_cpf = tk.Entry(reativar_window)
        entry_cpf.pack()

        tk.Button(reativar_window, text="Salvar", command=salvar_reativacao).pack()

    def visualizar_todos_pacientes():
        """
        Exibe a janela com a lista de todos os pacientes cadastrados.
        """
        todos_pacientes = db.listar_todos_pacientes()
        todos_pacientes_window = tk.Toplevel(menu_window)
        todos_pacientes_window.title("Todos os Pacientes")
        todos_pacientes_window.geometry("1366x768")
        set_window_icon(todos_pacientes_window)

        columns = ("ID", "Nome", "CPF")
        tree = ttk.Treeview(todos_pacientes_window, columns=columns, show="headings")
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=150)
        
        for paciente in todos_pacientes:
            tree.insert("", "end", values=(paciente['id'], paciente['nome'], paciente['cpf']))
        
        tree.pack(expand=True, fill="both")
        scrollbar = ttk.Scrollbar(todos_pacientes_window, orient="vertical", command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side="right", fill="y")

    def visualizar_historico_solicitacoes():
        """
        Exibe a janela com o histórico de solicitações de transporte.
        """
        historico = db.listar_historico_solicitacoes_transporte()
        historico_window = tk.Toplevel(menu_window)
        historico_window.title("Histórico de Solicitações de Transporte")
        historico_window.geometry("1366x768")
        set_window_icon(historico_window)

        columns = ("ID", "Descrição", "Paciente", "Urgência", "Maqueiro", "Data/Hora", "Data Conclusão")
        tree = ttk.Treeview(historico_window, columns=columns, show="headings")
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=150)
        
        for item in historico:
            data_hora_formatada = item['data_hora'].strftime("%d-%m-%Y %H:%M:%S") if item['data_hora'] else "N/A"
            data_conclusao_formatada = item['data_conclusao'].strftime("%d-%m-%Y %H:%M:%S") if item['data_conclusao'] else "N/A"
            print(f"Data/Hora Formatada: {data_hora_formatada}, Data Conclusão Formatada: {data_conclusao_formatada}")
            tree.insert("", "end", values=(
                item['id'], item['descricao'], item['paciente_nome'], item['urgencia'], item['maqueiro_nome'], 
                data_hora_formatada, data_conclusao_formatada
            ))
        
        tree.pack(expand=True, fill="both")
        scrollbar = ttk.Scrollbar(historico_window, orient="vertical", command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side="right", fill="y")


    # Botões para pacientes
    tk.Label(frame_pacientes, text="Gerenciamento de Pacientes", font=("Helvetica", 14, "bold"), bg="lightgrey").pack(pady=5)
    tk.Button(frame_pacientes, text="Cadastrar Paciente", command=cadastrar_paciente, width=30).pack(pady=5)
    tk.Button(frame_pacientes, text="Ver Status dos Pacientes", command=ver_status_pacientes, width=30).pack(pady=5)
    tk.Button(frame_pacientes, text="Atualizar Status do Paciente", command=atualizar_status_paciente, width=30).pack(pady=5)
    tk.Button(frame_pacientes, text="Liberar Paciente", command=liberar_paciente, width=30).pack(pady=5)
    tk.Button(frame_pacientes, text="Reativar Paciente", command=reativar_paciente, width=30).pack(pady=5)
    tk.Button(frame_pacientes, text="Visualizar Todos os Pacientes", command=visualizar_todos_pacientes, width=30).pack(pady=5)

    # Botões para transporte
    tk.Label(frame_transporte, text="Gerenciamento de Transporte", font=("Helvetica", 14, "bold"), bg="lightgrey").pack(pady=5)
    tk.Button(frame_transporte, text="Solicitar Transporte de Paciente", command=solicitar_transporte, width=30).pack(pady=5)
    tk.Button(frame_transporte, text="Ver Solicitações de Transporte", command=ver_solicitacoes, width=30).pack(pady=5)
    tk.Button(frame_transporte, text="Aceitar ou Recusar Solicitação", command=aceitar_ou_recusar_solicitacao, width=30).pack(pady=5)
    tk.Button(frame_transporte, text="Visualizar Histórico de Solicitações", command=visualizar_historico_solicitacoes, width=30).pack(pady=5)

    # Botões para tarefas e incidentes
    tk.Label(frame_tarefas_incidentes, text="Gerenciamento de Tarefas e Incidentes", font=("Helvetica", 14, "bold"), bg="lightgrey").pack(pady=5)
    tk.Button(frame_tarefas_incidentes, text="Adicionar Tarefa", command=adicionar_tarefa, width=30).pack(pady=5)
    tk.Button(frame_tarefas_incidentes, text="Concluir Tarefa", command=concluir_tarefa, width=30).pack(pady=5)
    tk.Button(frame_tarefas_incidentes, text="Listar Tarefas Pendentes", command=listar_tarefas_pendentes, width=30).pack(pady=5)
    tk.Button(frame_tarefas_incidentes, text="Relatar Incidente", command=relatar_incidente, width=30).pack(pady=5)

    # Botões gerais
    tk.Label(frame_geral, text="Outras Operações", font=("Helvetica", 14, "bold"), bg="lightgrey").pack(pady=5)
    tk.Button(frame_geral, text="Gerar Relatório", command=gerar_relatorio, width=30).pack(pady=5)
    tk.Button(frame_geral, text="Sair", command=sair, width=30).pack(pady=5)

    menu_window.protocol("WM_DELETE_WINDOW", sair)

def realizar_login(db):
    """
    Realiza o login de um usuário (administrador ou maqueiro).

    Args:
        db (Database): A instância do banco de dados.
    """
    login = entry_login.get()
    senha = entry_senha.get()

    if login == ADMIN_CREDENTIALS['login'] and senha == ADMIN_CREDENTIALS['senha']:
        messagebox.showinfo("Login", f"Bem-vindo, Administrador!")
        root.withdraw()  
        exibir_menu_admin(sistema_notificacoes, db)
        return

    maqueiro = db.buscar_maqueiro_por_login(login)
    if maqueiro and maqueiro.senha == senha:
        messagebox.showinfo("Login", f"Bem-vindo, {maqueiro.nome}!")
        root.withdraw() 
        exibir_menu(sistema_notificacoes, maqueiro, pacientes, maqueiros, tarefas, db)
    else:
        messagebox.showerror("Erro", "Login ou senha incorretos. Tente novamente.")

def main():
    """
    Função principal do programa. Configura a interface de login e inicializa o sistema.
    """
    global root, entry_login, entry_senha, sistema_notificacoes, pacientes, maqueiros, tarefas, db
    db = Database('localhost', 'root', '', 'hospital1')
    db.create_tables()
    sistema_notificacoes = SistemaDeNotificacoes()
    pacientes = []
    maqueiros = []
    tarefas = []

    root = tk.Tk()
    root.title("Login")
    root.geometry("1366x768")
    set_window_icon(root)

    # Carregar a imagem de fundo
    bg_image = Image.open("imagens/hospitalimage.jpg")
    bg_image = bg_image.resize((1366, 768), Image.LANCZOS)
    bg_photo = ImageTk.PhotoImage(bg_image)
    bg_label = tk.Label(root, image=bg_photo)
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)

    # Frame para centralizar os campos de login e senha
    login_frame = tk.Frame(root, bg="white")
    login_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

    tk.Label(login_frame, text="Login:", font=("Helvetica", 16), bg="white").pack(pady=10)
    entry_login = tk.Entry(login_frame, font=("Helvetica", 16))
    entry_login.pack()

    tk.Label(login_frame, text="Senha:", font=("Helvetica", 16), bg="white").pack(pady=10)
    entry_senha = tk.Entry(login_frame, show="*", font=("Helvetica", 16))
    entry_senha.pack()

    login_button = tk.Button(login_frame, text="Login", bg="blue", fg="white", font=("Helvetica", 16), command=lambda: realizar_login(db))
    login_button.pack(pady=20)

    root.mainloop()

if __name__ == "__main__":
    main()
