class SistemaDeNotificacoes:
    """
    Classe para gerenciar notificações no sistema hospitalar.
    """

    def __init__(self):
        """
        Inicializa uma nova instância do sistema de notificações.
        """
        self.notificacoes = []

    def adicionar_notificacao(self, notificacao):
        """
        Adiciona uma nova notificação ao sistema.

        :param notificacao: A notificação a ser adicionada
        """
        self.notificacoes.append(notificacao)
