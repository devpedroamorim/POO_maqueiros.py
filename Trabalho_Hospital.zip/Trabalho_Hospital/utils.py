"""
Módulo utils.py

Este módulo fornece utilidades para entrada de senha de forma segura.
"""

import msvcrt
import getpass

def input_senha(prompt):
    """
    Solicita ao usuário a entrada de uma senha de forma segura, substituindo os caracteres digitados por asteriscos.

    :param prompt: A mensagem a ser exibida solicitando a senha
    :return: A senha digitada pelo usuário
    """
    senha = []
    print(prompt, end='', flush=True)
    while True:
        char = msvcrt.getch()
        if char == b'\r':  
            break
        elif char == b'\b': 
            if len(senha) > 0:
                senha.pop()
                print('\b \b', end='', flush=True)
        else:
            senha.append(char.decode('utf-8'))
            print('*', end='', flush=True)
    print()
    return ''.join(senha)
    return getpass.getpass(prompt)
