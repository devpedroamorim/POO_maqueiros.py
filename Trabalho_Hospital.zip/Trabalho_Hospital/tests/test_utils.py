import unittest
from unittest.mock import patch
import utils

class TestUtils(unittest.TestCase):

    @patch('utils.msvcrt.getch')
    @patch('builtins.print')
    def test_input_senha(self, mock_print, mock_getch):
        # Mock the getch function to simulate user input
        mock_getch.side_effect = [b'a', b'b', b'c', b'\r']  # Simulate typing 'abc' and pressing Enter
        result = utils.input_senha("Enter password: ")
        self.assertEqual(result, 'abc')
        mock_print.print('Enter password: ', end='', flush=True)

if __name__ == '__main__':
    unittest.main()
