import unittest
from models import Paciente, Maqueiro, Tarefa, Incidente, SolicitacaoTransporte

class TestModels(unittest.TestCase):

    def test_paciente(self):
        paciente = Paciente('João', '12345678901', 'Quarto 101', 'Estável', 'Aguardando transporte', 'Emergencia')
        self.assertEqual(paciente.nome, 'João')
        self.assertEqual(paciente.cpf, '12345678901')
        self.assertEqual(paciente.localizacao, 'Quarto 101')
        self.assertEqual(paciente.condicao, 'Estável')
        self.assertEqual(paciente.transporte, 'Aguardando transporte')
        self.assertEqual(paciente.urgencia, 'Emergencia')
        self.assertTrue(paciente.ativo)

    def test_maqueiro(self):
        maqueiro = Maqueiro(1, 'Carlos', '12345678901', '01-01-1980', 'M')
        maqueiro.login = '12345678901'
        maqueiro.senha = 'senha123'
        self.assertEqual(maqueiro.id, 1)
        self.assertEqual(maqueiro.nome, 'Carlos')
        self.assertEqual(maqueiro.cpf, '12345678901')
        self.assertEqual(maqueiro.data_nascimento, '01-01-1980')
        self.assertEqual(maqueiro.sexo, 'M')
        self.assertEqual(maqueiro.login, '12345678901')
        self.assertEqual(maqueiro.senha, 'senha123')

    def test_tarefa(self):
        paciente = Paciente('João', '12345678901', 'Quarto 101', 'Estável', 'Aguardando transporte', 'Emergencia')
        paciente.id = 1
        maqueiro = Maqueiro(1, 'Carlos', '12345678901', '01-01-1980', 'M')
        tarefa = Tarefa(None, 'Transportar paciente', 'Alta', paciente, 'Quarto 101', maqueiro)
        self.assertIsNone(tarefa.id)
        self.assertEqual(tarefa.descricao, 'Transportar paciente')
        self.assertEqual(tarefa.prioridade, 'Alta')
        self.assertEqual(tarefa.status, 'pendente')
        self.assertEqual(tarefa.paciente, paciente)
        self.assertEqual(tarefa.localizacao, 'Quarto 101')
        self.assertEqual(tarefa.maqueiro, maqueiro)

    def test_incidente(self):
        paciente = Paciente('João', '12345678901', 'Quarto 101', 'Estável', 'Aguardando transporte', 'Emergencia')
        maqueiro = Maqueiro(1, 'Carlos', '12345678901', '01-01-1980', 'M')
        incidente = Incidente(None, 'Queda do paciente', maqueiro, paciente, '01-01-2022 10:00', 'Grave', 'Corredor', 'Paciente escorregou', 'Enfermeira Ana')
        self.assertIsNone(incidente.id)
        self.assertEqual(incidente.descricao, 'Queda do paciente')
        self.assertEqual(incidente.maqueiro, maqueiro)
        self.assertEqual(incidente.paciente, paciente)
        self.assertEqual(incidente.data_hora, '01-01-2022 10:00')
        self.assertEqual(incidente.gravidade, 'Grave')
        self.assertEqual(incidente.localizacao, 'Corredor')
        self.assertEqual(incidente.acoes_tomadas, 'Paciente escorregou')
        self.assertEqual(incidente.testemunhas, 'Enfermeira Ana')

    def test_solicitacao_transporte(self):
        paciente = Paciente('João', '12345678901', 'Quarto 101', 'Estável', 'Aguardando transporte', 'Emergencia')
        maqueiro = Maqueiro(1, 'Carlos', '12345678901', '01-01-1980', 'M')
        solicitacao = SolicitacaoTransporte(None, 'Transporte para tomografia', paciente, '01-01-2022 10:00', maqueiro, 'pendente')
        self.assertIsNone(solicitacao.id)
        self.assertEqual(solicitacao.descricao, 'Transporte para tomografia')
        self.assertEqual(solicitacao.paciente, paciente)
        self.assertEqual(solicitacao.data_hora, '01-01-2022 10:00')
        self.assertEqual(solicitacao.maqueiro, maqueiro)
        self.assertEqual(solicitacao.status, 'pendente')

if __name__ == '__main__':
    unittest.main()
