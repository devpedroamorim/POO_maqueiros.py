import unittest
from notificacoes import SistemaDeNotificacoes

class TestSistemaDeNotificacoes(unittest.TestCase):

    def test_adicionar_notificacao(self):
        sistema = SistemaDeNotificacoes()
        self.assertEqual(len(sistema.notificacoes), 0)
        sistema.adicionar_notificacao("Nova notificação")
        self.assertEqual(len(sistema.notificacoes), 1)
        self.assertEqual(sistema.notificacoes[0], "Nova notificação")

if __name__ == '__main__':
    unittest.main()
