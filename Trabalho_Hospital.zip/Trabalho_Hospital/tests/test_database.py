import unittest
from unittest.mock import patch, MagicMock
from database import Database
from models import Paciente, Maqueiro, Tarefa, Incidente, SolicitacaoTransporte

class TestDatabase(unittest.TestCase):

    @patch('mysql.connector.connect')
    def setUp(self, mock_connect):
        self.mock_connection = mock_connect.return_value
        self.mock_cursor = self.mock_connection.cursor.return_value
        self.db = Database('localhost', 'root', '', 'hospital1')

    def test_insert_paciente(self):
        paciente = Paciente('João', '12345678901', 'Quarto 101', 'Estável', 'Aguardando transporte', 'Emergencia')
        self.db.insert_paciente(paciente)
        self.mock_cursor.execute.assert_called_once_with(
            "INSERT INTO Pacientes (nome, cpf, localizacao, condicao, urgencia) VALUES (%s, %s, %s, %s, %s)",
            ('João', '12345678901', 'Quarto 101', 'Estável', 'Emergencia')
        )
        self.mock_connection.commit.assert_called_once()

    def test_insert_maqueiro(self):
        maqueiro = Maqueiro(None, 'Carlos', '12345678901', '01-01-1980', 'M')
        maqueiro.login = '12345678901'
        maqueiro.senha = 'senha123'
        self.db.insert_maqueiro(maqueiro)
        self.mock_cursor.execute.assert_called_once_with(
            "INSERT INTO Maqueiros (nome, cpf, data_nascimento, sexo, login, senha) VALUES (%s, %s, %s, %s, %s, %s)",
            ('Carlos', '12345678901', '01-01-1980', 'M', '12345678901', 'senha123')
        )
        self.mock_connection.commit.assert_called_once()

    def test_insert_tarefa(self):
        paciente = Paciente('João', '12345678901', 'Quarto 101', 'Estável', 'Aguardando transporte', 'Emergencia')
        paciente.id = 1
        maqueiro = Maqueiro(1, 'Carlos', '12345678901', '01-01-1980', 'M')
        tarefa = Tarefa(None, 'Transportar paciente', 'Alta', paciente, 'Quarto 101', maqueiro)
        self.db.insert_tarefa(tarefa)
        self.mock_cursor.execute.assert_called_once_with(
            "INSERT INTO Tarefas (descricao, prioridade, status, paciente_id, localizacao, maqueiro_id) VALUES (%s, %s, %s, %s, %s, %s)",
            ('Transportar paciente', 'Alta', 'pendente', 1, 'Quarto 101', 1)
        )
        self.mock_connection.commit.assert_called_once()

    def test_update_tarefa_status(self):
        self.db.update_tarefa_status(1, 'concluída')
        self.mock_cursor.execute.assert_called_once_with(
            "UPDATE Tarefas SET status = %s WHERE id = %s",
            ('concluída', 1)
        )
        self.mock_connection.commit.assert_called_once()

if __name__ == '__main__':
    unittest.main()
