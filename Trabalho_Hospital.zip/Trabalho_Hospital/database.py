import mysql.connector
from mysql.connector import Error
import datetime
from models import Maqueiro, Tarefa, Paciente, SolicitacaoTransporte, Incidente

class Database:
    """
    Classe que gerencia a conexão e as operações com o banco de dados MySQL para o sistema hospitalar.
    """

    def __init__(self, host, user, password, database):
        """
        Inicializa a conexão com o banco de dados.

        :param host: Endereço do servidor MySQL
        :param user: Nome de usuário do MySQL
        :param password: Senha do MySQL
        :param database: Nome do banco de dados a ser usado
        """
        self.connection = None
        try:
            self.connection = mysql.connector.connect(
                host='localhost',
                user='root',
                password='',
                database='hospital1'
            )
            self.cursor = self.connection.cursor()
            print("Conexão com o banco de dados estabelecida.")
        except Error as e:
            print(f"Erro ao conectar ao banco de dados: {e}")

    def create_tables(self):
        """
        Cria as tabelas necessárias no banco de dados.
        """
        try:
            self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Pacientes (
                id INT PRIMARY KEY AUTO_INCREMENT,
                nome VARCHAR(100),
                cpf VARCHAR(11) UNIQUE,
                localizacao VARCHAR(100),
                condicao TEXT,
                urgencia ENUM('Emergencia', 'Urgência', 'Pouco Urgente', 'Não urgente'),
                transporte ENUM('Aguardando transporte', 'Em transporte', 'Chegou ao destino') DEFAULT 'Aguardando transporte',
                inicio_transporte DATETIME,
                ativo BOOLEAN DEFAULT TRUE
            )""")

            self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Maqueiros (
                id INT PRIMARY KEY AUTO_INCREMENT,
                nome VARCHAR(100),
                cpf VARCHAR(11) UNIQUE,
                data_nascimento DATE,
                sexo ENUM('M', 'F'),
                login VARCHAR(50) UNIQUE,
                senha VARCHAR(100)
            )""")

            self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Tarefas (
                id INT PRIMARY KEY AUTO_INCREMENT,
                descricao VARCHAR(255),
                prioridade VARCHAR(50),
                status VARCHAR(50),
                paciente_id INT,
                localizacao VARCHAR(100),
                maqueiro_id INT,
                FOREIGN KEY (paciente_id) REFERENCES Pacientes(id),
                FOREIGN KEY (maqueiro_id) REFERENCES Maqueiros(id)
            )""")

            self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Incidentes (
                id INT PRIMARY KEY AUTO_INCREMENT,
                descricao VARCHAR(255),
                maqueiro_id INT,
                paciente_id INT,
                data_hora DATETIME,
                gravidade ENUM('Leve', 'Moderada', 'Grave', 'Crítica'),
                localizacao VARCHAR(100),
                acoes_tomadas TEXT,
                testemunhas TEXT,
                FOREIGN KEY (maqueiro_id) REFERENCES Maqueiros(id),
                FOREIGN KEY (paciente_id) REFERENCES Pacientes(id)
            )""")

            self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS SolicitacoesTransporte (
                id INT PRIMARY KEY AUTO_INCREMENT,
                descricao VARCHAR(255),
                paciente_id INT,
                urgencia ENUM('Emergencia', 'Urgência', 'Pouco Urgente', 'Não urgente'),
                status VARCHAR(50),
                maqueiro_id INT,
                data_hora DATETIME,
                FOREIGN KEY (paciente_id) REFERENCES Pacientes(id),
                FOREIGN KEY (maqueiro_id) REFERENCES Maqueiros(id)
            )""")
            
            self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS HistoricoSolicitacoesTransporte (
                id INT PRIMARY KEY AUTO_INCREMENT,
                descricao VARCHAR(255),
                paciente_id INT,
                urgencia ENUM('Emergencia', 'Urgência', 'Pouco Urgente', 'Não urgente'),
                status VARCHAR(50),
                maqueiro_id INT,
                data_hora DATETIME,
                data_conclusao DATETIME,
                FOREIGN KEY (paciente_id) REFERENCES Pacientes(id),
                FOREIGN KEY (maqueiro_id) REFERENCES Maqueiros(id)
            )""")
            self.connection.commit()
        except Error as e:
            print(f"Erro ao criar tabelas: {e}")

    def insert_paciente(self, paciente):
        """
        Insere um novo paciente no banco de dados.

        :param paciente: Objeto Paciente a ser inserido
        :return: ID do paciente inserido ou None em caso de erro
        """
        try:
            self.cursor.execute("INSERT INTO Pacientes (nome, cpf, localizacao, condicao, urgencia) VALUES (%s, %s, %s, %s, %s)",
                                (paciente.nome, paciente.cpf, paciente.localizacao, paciente.condicao, paciente.urgencia))
            self.connection.commit()
            return self.cursor.lastrowid
        except Error as e:
            print(f"Erro ao inserir paciente no banco de dados: {e}")
            return None

    
    def insert_maqueiro(self, maqueiro):
        """
        Insere um novo maqueiro no banco de dados.

        :param maqueiro: Objeto Maqueiro a ser inserido
        :return: ID do maqueiro inserido ou None em caso de erro
        """
        try:
            self.cursor.execute("INSERT INTO Maqueiros (nome, cpf, data_nascimento, sexo, login, senha) VALUES (%s, %s, %s, %s, %s, %s)",
                                (maqueiro.nome, maqueiro.cpf, maqueiro.data_nascimento, maqueiro.sexo, maqueiro.login, maqueiro.senha))
            self.connection.commit()
            return self.cursor.lastrowid
        except Error as e:
            print(f"Erro ao inserir maqueiro no banco de dados: {e}")
            return None


    def insert_tarefa(self, tarefa):
        """
        Insere uma nova tarefa no banco de dados.

        :param tarefa: Objeto Tarefa a ser inserido
        :return: ID da tarefa inserida ou None em caso de erro
        """
        try:
            self.cursor.execute("INSERT INTO Tarefas (descricao, prioridade, status, paciente_id, localizacao, maqueiro_id) VALUES (%s, %s, %s, %s, %s, %s)",
                                (tarefa.descricao, tarefa.prioridade, tarefa.status, tarefa.paciente.id, tarefa.localizacao, tarefa.maqueiro.id if tarefa.maqueiro else None))
            self.connection.commit()
            return self.cursor.lastrowid
        except Error as e:
            print(f"Erro ao inserir tarefa no banco de dados: {e}")
            return None

    def update_tarefa_status(self, tarefa_id, status):
        """
        Atualiza o status de uma tarefa no banco de dados.

        :param tarefa_id: ID da tarefa a ser atualizada
        :param status: Novo status da tarefa
        """
        try:
            self.cursor.execute("UPDATE Tarefas SET status = %s WHERE id = %s", (status, tarefa_id))
            self.connection.commit()
        except Error as e:
            print(f"Erro ao atualizar status da tarefa no banco de dados: {e}")

    def insert_incidente(self, incidente):
        """
        Insere um novo incidente no banco de dados.

        :param incidente: Objeto Incidente a ser inserido
        """
        try:
            self.cursor.execute("INSERT INTO Incidentes (descricao, maqueiro_id, paciente_id, data_hora, gravidade, localizacao, acoes_tomadas, testemunhas) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                                (incidente.descricao, incidente.maqueiro.id, incidente.paciente.id, incidente.data_hora, incidente.gravidade, incidente.localizacao, incidente.acoes_tomadas, incidente.testemunhas))
            self.connection.commit()
        except Error as e:
            print(f"Erro ao inserir incidente no banco de dados: {e}")

    def insert_solicitacao_transporte(self, solicitacao):
        """
        Insere uma nova solicitação de transporte no banco de dados.

        :param solicitacao: Objeto SolicitacaoTransporte a ser inserido
        :return: ID da solicitação inserida ou None em caso de erro
        """
        try:
            self.cursor.execute("INSERT INTO SolicitacoesTransporte (descricao, paciente_id, urgencia, status, maqueiro_id, data_hora) VALUES (%s, %s, %s, %s, %s, %s)",
                                (solicitacao.descricao, solicitacao.paciente.id, solicitacao.paciente.urgencia, solicitacao.status, solicitacao.maqueiro.id if solicitacao.maqueiro else None, datetime.datetime.now()))
            self.connection.commit()
            return self.cursor.lastrowid
        except Error as e:
            print(f"Erro ao inserir solicitação de transporte no banco de dados: {e}")
            return None



    def buscar_paciente_por_cpf(self, cpf):
        """
        Busca um paciente pelo CPF.

        :param cpf: CPF do paciente a ser buscado
        :return: Objeto Paciente encontrado ou None se não encontrado
        """
        self.cursor.execute("SELECT id, nome, cpf, localizacao, condicao, urgencia, transporte, ativo FROM Pacientes WHERE cpf = %s", (cpf,))
        result = self.cursor.fetchone()
        if result:
            paciente = Paciente(result[1], result[2], result[3], result[4], result[6], result[5])
            paciente.id = result[0]
            paciente.ativo = result[7]
            return paciente
        return None

    def buscar_maqueiro_por_login(self, login):
        """
        Busca um maqueiro pelo login.

        :param login: Login do maqueiro a ser buscado
        :return: Objeto Maqueiro encontrado ou None se não encontrado
        """
        self.cursor.execute("SELECT id, nome, cpf, data_nascimento, sexo, login, senha FROM Maqueiros WHERE login = %s", (login,))
        result = self.cursor.fetchone()
        if result:
            maqueiro = Maqueiro(result[0], result[1], result[2], result[3], result[4])
            maqueiro.login = result[5]
            maqueiro.senha = result[6]
            return maqueiro
        return None

    def buscar_maqueiro_por_cpf(self, cpf):
        """
        Busca um maqueiro pelo CPF.

        :param cpf: CPF do maqueiro a ser buscado
        :return: Objeto Maqueiro encontrado ou None se não encontrado
        """
        self.cursor.execute("SELECT id, nome, cpf, data_nascimento, sexo, login, senha FROM Maqueiros WHERE cpf = %s", (cpf,))
        result = self.cursor.fetchone()
        if result:
            maqueiro = Maqueiro(result[0], result[1], result[2], result[3], result[4])
            maqueiro.login = result[5]
            maqueiro.senha = result[6]
            return maqueiro
        return None

    def listar_tarefas_pendentes(self):
        """
        Lista todas as tarefas pendentes.

        :return: Lista de objetos Tarefa pendentes
        """
        self.cursor.execute("SELECT id, descricao, prioridade, paciente_id, localizacao, maqueiro_id FROM Tarefas WHERE status = 'pendente'")
        result = self.cursor.fetchall()
        tarefas = []
        for row in result:
            paciente = self.buscar_paciente_por_id(row[3])
            maqueiro = self.buscar_maqueiro_por_id(row[5]) if row[5] else None
            tarefa = Tarefa(row[0], row[1], row[2], paciente, row[4], maqueiro)
            tarefas.append(tarefa)
        return tarefas

    def buscar_paciente_por_id(self, paciente_id):
        """
        Busca um paciente pelo ID.

        :param paciente_id: ID do paciente a ser buscado
        :return: Objeto Paciente encontrado ou None se não encontrado
        """
        self.cursor.execute("SELECT id, nome, cpf, localizacao, condicao, urgencia, transporte FROM Pacientes WHERE id = %s", (paciente_id,))
        result = self.cursor.fetchone()
        if result:
            paciente = Paciente(result[1], result[2], result[3], result[4], result[6], result[5])
            paciente.id = result[0]
            return paciente
        return None

    def buscar_maqueiro_por_id(self, maqueiro_id):
        """
        Busca um maqueiro pelo ID.

        :param maqueiro_id: ID do maqueiro a ser buscado
        :return: Objeto Maqueiro encontrado ou None se não encontrado
        """
        self.cursor.execute("SELECT id, nome, cpf, data_nascimento, sexo, login, senha FROM Maqueiros WHERE id = %s", (maqueiro_id,))
        result = self.cursor.fetchone()
        if result:
            maqueiro = Maqueiro(result[0], result[1], result[2], result[3], result[4])
            maqueiro.login = result[5]
            maqueiro.senha = result[6]
            return maqueiro
        return None

    def listar_solicitacoes_pendentes(self):
        """
        Lista todas as solicitações de transporte pendentes.

        :return: Lista de objetos SolicitacaoTransporte pendentes
        """
        self.cursor.execute("SELECT id, descricao, paciente_id, status, maqueiro_id, data_hora FROM SolicitacoesTransporte WHERE status = 'pendente'")
        result = self.cursor.fetchall()
        solicitacoes = []
        for row in result:
            paciente = self.buscar_paciente_por_id(row[2])
            maqueiro = self.buscar_maqueiro_por_id(row[4]) if row[4] else None
            solicitacao = SolicitacaoTransporte(row[0], row[1], paciente, row[5], maqueiro, row[3])
            solicitacoes.append(solicitacao)
        return solicitacoes

    def update_solicitacao_status(self, solicitacao_id, status, maqueiro_id):
        """
        Atualiza o status de uma solicitação de transporte no banco de dados.

        :param solicitacao_id: ID da solicitação a ser atualizada
        :param status: Novo status da solicitação
        :param maqueiro_id: ID do maqueiro responsável pela solicitação
        """
        try:
            self.cursor.execute("UPDATE SolicitacoesTransporte SET status = %s, maqueiro_id = %s, data_conclusao = NOW() WHERE id = %s", (status, maqueiro_id, solicitacao_id))
            self.connection.commit()
        except Error as e:
            print(f"Erro ao atualizar status da solicitação de transporte no banco de dados: {e}")


    def listar_historico_solicitacoes_transporte(self):
        """
        Lista o historico de solicitações de transporte.
        """
        try:
            self.cursor.execute("""
            SELECT h.id, h.descricao, p.nome AS paciente_nome, h.urgencia, h.status, m.nome AS maqueiro_nome, h.data_hora, h.data_conclusao
            FROM HistoricoSolicitacoesTransporte h
            LEFT JOIN Pacientes p ON h.paciente_id = p.id
            LEFT JOIN Maqueiros m ON h.maqueiro_id = m.id
            """)
            result = self.cursor.fetchall()
            historico = []
            for row in result:
                historico.append({
                    'id': row[0],
                    'descricao': row[1],
                    'paciente_nome': row[2],
                    'urgencia': row[3],
                    'status': row[4],
                    'maqueiro_nome': row[5],
                    'data_hora': row[6],
                    'data_conclusao': row[7]
                })
            return historico
        except Error as e:
            print(f"Erro ao listar histórico de solicitações de transporte: {e}")
            return []


    def iniciar_transporte_paciente(self, paciente_id):
        """
        Inicia o transporte de um paciente, atualizando o status e a hora de início do transporte.

        :param paciente_id: ID do paciente a ser transportado
        """
        try:
            self.cursor.execute("UPDATE Pacientes SET transporte = 'Em transporte', inicio_transporte = %s WHERE id = %s",
            (datetime.datetime.now(), paciente_id))
            self.connection.commit()
        except Error as e:
            print(f"Erro ao iniciar transporte do paciente: {e}")
            
    def atualizar_status_transporte(self):
        """
        Atualiza o status de transporte dos pacientes em trânsito após um determinado tempo.
        """
        try:
            self.cursor.execute("SELECT id, inicio_transporte FROM Pacientes WHERE condicao = 'Em transporte'")
            pacientes_em_transporte = self.cursor.fetchall()
            for paciente_id, inicio_transporte in pacientes_em_transporte:
                tempo_em_transporte = datetime.datetime.now() - inicio_transporte
                if tempo_em_transporte.total_seconds() > 3600:  
                    self.cursor.execute("UPDATE Pacientes SET transporte = 'Chegou ao destino' WHERE id = %s", (paciente_id,))
            self.connection.commit()
        except Error as e:
            print(f"Erro ao atualizar status de transporte: {e}")

    def concluir_transporte_paciente(self, paciente_id):
        """
        Conclui o transporte de um paciente, atualizando o status e resetando a hora de início do transporte.

        :param paciente_id: ID do paciente cujo transporte foi concluído
        """
        try:
            self.cursor.execute("UPDATE Pacientes SET transporte = 'Chegou ao destino', inicio_transporte = NULL WHERE id = %s", (paciente_id,))
            self.connection.commit()
        except Error as e:
            print(f"Erro ao concluir transporte do paciente: {e}")

    def atualizar_transporte_paciente(self, paciente_id, status_transporte):
        """
        Atualiza o status de transporte de um paciente.

        :param paciente_id: ID do paciente a ser atualizado
        :param status_transporte: Novo status de transporte do paciente
        """
        try:
            self.cursor.execute("UPDATE Pacientes SET transporte = %s WHERE id = %s", (status_transporte, paciente_id))
            self.connection.commit()
        except Error as e:
            print(f"Erro ao atualizar transporte do paciente: {e}")

    def listar_pacientes(self):
        """
        Lista todos os pacientes ativos.

        :return: Lista de objetos Paciente ativos
        """
        try:
            self.cursor.execute("SELECT id, nome, cpf, localizacao, condicao, urgencia, transporte FROM Pacientes WHERE ativo = TRUE")
            result = self.cursor.fetchall()
            pacientes = []
            for row in result:
                paciente = Paciente(row[1], row[2], row[3], row[4], row[6], row[5])
                paciente.id = row[0]
                pacientes.append(paciente)
            return pacientes
        except Error as e:
            print(f"Erro ao listar pacientes: {e}")
            return []

    def listar_todos_pacientes(self):
        """
        Lista todos os pacientes, ativos ou inativos.

        :return: Lista de dicionários com informações básicas dos pacientes
        """
        try:
            self.cursor.execute("SELECT id, nome, cpf FROM Pacientes")
            result = self.cursor.fetchall()
            pacientes = []
            for row in result:
                pacientes.append({
                    'id': row[0],
                    'nome': row[1],
                    'cpf': row[2]
                })
            return pacientes
        except Error as e:
            print(f"Erro ao listar todos os pacientes: {e}")
            return []
        
    def listar_pacientes_por_urgencia(self):
        """
        Lista todos os pacientes ordenados por urgência.

        :return: Lista de objetos Paciente ordenados por urgência
        """
        try:
            self.cursor.execute("SELECT id, nome, cpf, localizacao, condicao, urgencia, transporte FROM Pacientes WHERE ativo = TRUE ORDER BY FIELD(urgencia, 'Emergencia', 'Urgência', 'Pouco Urgente', 'Não urgente')")
            result = self.cursor.fetchall()
            pacientes = []
            for row in result:
                paciente = Paciente(row[1], row[2], row[3], row[4], row[6], row[5])
                paciente.id = row[0]
                pacientes.append(paciente)
            return pacientes
        except Error as e:
            print(f"Erro ao listar pacientes por urgência: {e}")
            return []

    def atualizar_paciente(self, paciente):
        """
        Atualiza as informações de um paciente no banco de dados.

        :param paciente: Objeto Paciente a ser atualizado
        """
        try:
            self.cursor.execute("UPDATE Pacientes SET localizacao = %s, urgencia = %s, condicao = %s WHERE id = %s",
                                (paciente.localizacao, paciente.urgencia, paciente.condicao, paciente.id))
            self.connection.commit()
        except Error as e:
            print(f"Erro ao atualizar paciente no banco de dados: {e}")

    def liberar_paciente(self, paciente_id):
        """
        Marca um paciente como inativo no banco de dados.

        :param paciente_id: ID do paciente a ser liberado
        """
        try:
            self.cursor.execute("UPDATE Pacientes SET ativo = FALSE WHERE id = %s", (paciente_id,))
            self.connection.commit()
        except Error as e:
            print(f"Erro ao liberar paciente: {e}")
            
    def deletar_paciente(self, paciente_id):
        """
        Deleta um paciente do banco de dados.

        :param paciente_id: ID do paciente a ser deletado
        """
        try:
            self.cursor.execute("DELETE FROM Pacientes WHERE id = %s", (paciente_id,))
            self.connection.commit()
            print(f"Paciente com ID {paciente_id} foi deletado com sucesso.")
        except Error as e:
            print(f"Erro ao deletar paciente no banco de dados: {e}")

    def reativar_paciente(self, cpf):
        """
        Reativa um paciente inativo no banco de dados.

        :param cpf: CPF do paciente a ser reativado
        """
        try:
            self.cursor.execute("UPDATE Pacientes SET ativo = TRUE WHERE cpf = %s", (cpf,))
            self.connection.commit()
        except Error as e:
            print(f"Erro ao reativar paciente: {e}")

    def mover_solicitacao_para_historico(self, solicitacao_id):
        """
        Move uma solicitação de transporte para o histórico de solicitações.

        :param solicitacao_id: ID da solicitação a ser movida
        """
        try:
            self.cursor.execute("""
            INSERT INTO HistoricoSolicitacoesTransporte (descricao, paciente_id, urgencia, status, maqueiro_id, data_hora, data_conclusao)
            SELECT descricao, paciente_id, urgencia, status, maqueiro_id, data_hora, NOW()
            FROM SolicitacoesTransporte WHERE id = %s
            """, (solicitacao_id,))
            self.cursor.execute("DELETE FROM SolicitacoesTransporte WHERE id = %s", (solicitacao_id,))
            self.connection.commit()
        except Error as e:
            print(f"Erro ao mover solicitação para histórico: {e}")


    def listar_historico_solicitacoes_transporte(self):
        """
        Lista o historico de solicitações de transporte.
        """
        try:
            self.cursor.execute("""
            SELECT h.id, h.descricao, p.nome AS paciente_nome, h.urgencia, m.nome AS maqueiro_nome, h.data_hora, h.data_conclusao
            FROM HistoricoSolicitacoesTransporte h
            LEFT JOIN Pacientes p ON h.paciente_id = p.id
            LEFT JOIN Maqueiros m ON h.maqueiro_id = m.id
            """)
            result = self.cursor.fetchall()
            historico = []
            for row in result:
                historico.append({
                    'id': row[0],
                    'descricao': row[1],
                    'paciente_nome': row[2],
                    'urgencia': row[3],
                    'maqueiro_nome': row[4],
                    'data_hora': row[5],
                    'data_conclusao': row[6]
                })
            return historico
        except Error as e:
            print(f"Erro ao listar histórico de solicitações de transporte: {e}")
            return []


    def close_connection(self):
        """
        Fecha a conexão com o banco de dados.
        """
        if self.connection.is_connected():
            self.cursor.close()
            self.connection.close()
            print("Conexão com o banco de dados encerrada.")
