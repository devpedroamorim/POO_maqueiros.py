class Paciente:
    """
    Representa um paciente no sistema hospitalar.

    Atributos:
        id (int): O identificador único do paciente.
        nome (str): O nome do paciente.
        cpf (str): O CPF do paciente.
        localizacao (str): A localização atual do paciente.
        condicao (str): A condição de saúde do paciente.
        transporte (str): O status de transporte do paciente.
        urgencia (str): O nível de urgência do paciente.
        ativo (bool): Indica se o paciente está ativo no sistema.
    """

    def __init__(self, nome, cpf, localizacao, condicao, transporte, urgencia):
        """
        Inicializa um novo paciente.

        Args:
            nome (str): O nome do paciente.
            cpf (str): O CPF do paciente.
            localizacao (str): A localização atual do paciente.
            condicao (str): A condição de saúde do paciente.
            transporte (str): O status de transporte do paciente.
            urgencia (str): O nível de urgência do paciente.
        """
        self.id = None
        self.nome = nome
        self.cpf = cpf
        self.localizacao = localizacao
        self.condicao = condicao
        self.transporte = transporte
        self.urgencia = urgencia
        self.ativo = True

    def definir_id(self, id):
        """
        Define o identificador único do paciente.

        Args:
            id (int): O identificador único do paciente.
        """
        self._id = id

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, id):
        self._id = id

    @property
    def nome(self):
        return self._nome

    @nome.setter
    def nome(self, nome):
        self._nome = nome

    @property
    def cpf(self):
        return self._cpf

    @cpf.setter
    def cpf(self, cpf):
        self._cpf = cpf

    @property
    def localizacao(self):
        return self._localizacao

    @localizacao.setter
    def localizacao(self, localizacao):
        self._localizacao = localizacao

    @property
    def condicao(self):
        return self._condicao

    @condicao.setter
    def condicao(self, condicao):
        self._condicao = condicao

    @property
    def transporte(self):
        return self._transporte

    @transporte.setter
    def transporte(self, transporte):
        self._transporte = transporte

    @property
    def urgencia(self):
        return self._urgencia

    @urgencia.setter
    def urgencia(self, urgencia):
        self._urgencia = urgencia


class Maqueiro:
    """
    Representa um maqueiro no sistema hospitalar.

    Atributos:
        id (int): O identificador único do maqueiro.
        nome (str): O nome do maqueiro.
        coren (str): O COREN do maqueiro.
        data_nascimento (str): A data de nascimento do maqueiro.
        sexo (str): O sexo do maqueiro.
        login (str): O login do maqueiro.
        senha (str): A senha do maqueiro.
    """

    def __init__(self, id, nome, cpf, data_nascimento, sexo):
        """
        Inicializa um novo maqueiro.

        Args:
            id (int): O identificador único do maqueiro.
            nome (str): O nome do maqueiro.
            coren (str): O COREN do maqueiro.
            data_nascimento (str): A data de nascimento do maqueiro.
            sexo (str): O sexo do maqueiro.
        """
        self.id = id
        self.nome = nome
        self.cpf = cpf
        self.data_nascimento = data_nascimento
        self.sexo = sexo
        self.login = cpf
        self.senha = None

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, id):
        self._id = id

    @property
    def nome(self):
        return self._nome

    @nome.setter
    def nome(self, nome):
        self._nome = nome

    @property
    def coren(self):
        return self._coren

    @coren.setter
    def coren(self, coren):
        self._coren = coren

    @property
    def data_nascimento(self):
        return self._data_nascimento

    @data_nascimento.setter
    def data_nascimento(self, data_nascimento):
        self._data_nascimento = data_nascimento

    @property
    def sexo(self):
        return self._sexo

    @sexo.setter
    def sexo(self, sexo):
        self._sexo = sexo

    @property
    def login(self):
        return self._login

    @login.setter
    def login(self, login):
        self._login = login

    @property
    def senha(self):
        return self._senha

    @senha.setter
    def senha(self, senha):
        self._senha = senha

    @property
    def tarefas(self):
        return self._tarefas

    @tarefas.setter
    def tarefas(self, tarefas):
        self._tarefas = tarefas

    def adicionar_tarefa(self, tarefa):
        """
        Adiciona uma tarefa à lista de tarefas do maqueiro.

        Args:
            tarefa (Tarefa): A tarefa a ser adicionada.
        """
        self._tarefas.append(tarefa)


class Tarefa:
    """
    Representa uma tarefa no sistema hospitalar.

    Atributos:
        id (int): O identificador único da tarefa.
        descricao (str): A descrição da tarefa.
        prioridade (str): A prioridade da tarefa.
        status (str): O status da tarefa (pendente/concluída).
        paciente (Paciente): O paciente relacionado à tarefa.
        localizacao (str): A localização onde a tarefa deve ser realizada.
        maqueiro (Maqueiro): O maqueiro responsável pela tarefa.
    """

    def __init__(self, id, descricao, prioridade, paciente, localizacao, maqueiro):
        """
        Inicializa uma nova tarefa.

        Args:
            id (int): O identificador único da tarefa.
            descricao (str): A descrição da tarefa.
            prioridade (str): A prioridade da tarefa.
            paciente (Paciente): O paciente relacionado à tarefa.
            localizacao (str): A localização onde a tarefa deve ser realizada.
            maqueiro (Maqueiro): O maqueiro responsável pela tarefa.
        """
        self.id = id
        self.descricao = descricao
        self.prioridade = prioridade
        self.status = 'pendente'
        self.paciente = paciente
        self.localizacao = localizacao
        self.maqueiro = maqueiro

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, id):
        self._id = id

    @property
    def descricao(self):
        return self._descricao

    @descricao.setter
    def descricao(self, descricao):
        self._descricao = descricao

    @property
    def prioridade(self):
        return self._prioridade

    @prioridade.setter
    def prioridade(self, prioridade):
        self._prioridade = prioridade

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, status):
        self._status = status

    @property
    def paciente(self):
        return self._paciente

    @paciente.setter
    def paciente(self, paciente):
        self._paciente = paciente

    @property
    def localizacao(self):
        return self._localizacao

    @localizacao.setter
    def localizacao(self, localizacao):
        self._localizacao = localizacao

    @property
    def maqueiro(self):
        return self._maqueiro

    @maqueiro.setter
    def maqueiro(self, maqueiro):
        self._maqueiro = maqueiro


class Incidente:
    """
    Representa um incidente no sistema hospitalar.

    Atributos:
        id (int): O identificador único do incidente.
        descricao (str): A descrição do incidente.
        maqueiro (Maqueiro): O maqueiro envolvido no incidente.
        paciente (Paciente): O paciente envolvido no incidente.
        data_hora (str): A data e hora do incidente.
        gravidade (str): A gravidade do incidente.
        localizacao (str): A localização do incidente.
        acoes_tomadas (str): As ações tomadas em resposta ao incidente.
        testemunhas (str): As testemunhas do incidente.
    """

    def __init__(self, id, descricao, maqueiro, paciente, data_hora, gravidade, localizacao, acoes_tomadas, testemunhas):
        """
        Inicializa um novo incidente.

        Args:
            id (int): O identificador único do incidente.
            descricao (str): A descrição do incidente.
            maqueiro (Maqueiro): O maqueiro envolvido no incidente.
            paciente (Paciente): O paciente envolvido no incidente.
            data_hora (str): A data e hora do incidente.
            gravidade (str): A gravidade do incidente.
            localizacao (str): A localização do incidente.
            acoes_tomadas (str): As ações tomadas em resposta ao incidente.
            testemunhas (str): As testemunhas do incidente.
        """
        self.id = id
        self.descricao = descricao
        self.maqueiro = maqueiro
        self.paciente = paciente
        self.data_hora = data_hora
        self.gravidade = gravidade
        self.localizacao = localizacao
        self.acoes_tomadas = acoes_tomadas
        self.testemunhas = testemunhas

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, id):
        self._id = id

    @property
    def descricao(self):
        return self._descricao

    @descricao.setter
    def descricao(self, descricao):
        self._descricao = descricao

    @property
    def maqueiro(self):
        return self._maqueiro

    @maqueiro.setter
    def maqueiro(self, maqueiro):
        self._maqueiro = maqueiro

    @property
    def paciente(self):
        return self._paciente

    @paciente.setter
    def paciente(self, paciente):
        self._paciente = paciente

    @property
    def data_hora(self):
        return self._data_hora

    @data_hora.setter
    def data_hora(self, data_hora):
        self._data_hora = data_hora

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, status):
        self._status = status


class SolicitacaoTransporte:
    """
    Representa uma solicitação de transporte no sistema hospitalar.

    Atributos:
        id (int): O identificador único da solicitação.
        descricao (str): A descrição da solicitação.
        paciente (Paciente): O paciente relacionado à solicitação.
        data_hora (str): A data e hora da solicitação.
        maqueiro (Maqueiro): O maqueiro responsável pela solicitação.
        status (str): O status da solicitação.
    """

    def __init__(self, id, descricao, paciente, data_hora, maqueiro, status):
        """
        Inicializa uma nova solicitação de transporte.

        Args:
            id (int): O identificador único da solicitação.
            descricao (str): A descrição da solicitação.
            paciente (Paciente): O paciente relacionado à solicitação.
            data_hora (str): A data e hora da solicitação.
            maqueiro (Maqueiro): O maqueiro responsável pela solicitação.
            status (str): O status da solicitação.
        """
        self.id = id
        self.descricao = descricao
        self.paciente = paciente
        self.data_hora = data_hora
        self.maqueiro = maqueiro
        self.status = status

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, id):
        self._id = id

    @property
    def descricao(self):
        return self._descricao

    @descricao.setter
    def descricao(self, descricao):
        self._descricao = descricao

    @property
    def paciente(self):
        return self._paciente

    @paciente.setter
    def paciente(self, paciente):
        self._paciente = paciente

    @property
    def data_hora(self):
        return self._data_hora

    @data_hora.setter
    def data_hora(self, data_hora):
        self._data_hora = data_hora

    @property
    def maqueiro(self):
        return self._maqueiro

    @maqueiro.setter
    def maqueiro(self, maqueiro):
        self._maqueiro = maqueiro

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, status):
        self._status = status
